package Telas;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableRowSorter;

import Classes.Despesa;
import Classes.Receita;
import Classes.Usuario;
import DAO.DespesasDAO;
import Swing.CentralizedTableCellRenderer;
import Swing.CustomHeaderRenderer;
import Swing.RoundedButton;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.awt.Cursor;

public class TelaDespesa extends JPanel {
    private DefaultTableModel tabelaDespesas;
    private JTable table;
    private static final SimpleDateFormat dataFormat = new SimpleDateFormat("dd/MM/yyyy");
    Despesa despesa = new Despesa();
	/**
	 * Create the panel.
	 */
	public TelaDespesa(Usuario usu) {
		setBounds(0, 0, 691, 498);
		setLayout(null);
		setBackground(Color.WHITE);
		
		JLabel lblDespesas = new JLabel("Despesas");
		lblDespesas.setFont(new Font("Century Gothic", Font.BOLD, 30));
		lblDespesas.setForeground(new Color(40, 66, 159));
		lblDespesas.setBounds(28, 0, 142, 85);
		add(lblDespesas);
		
		 // DefaultTableModel com as colunas
        tabelaDespesas = new DefaultTableModel();
        tabelaDespesas.addColumn("ID");
        tabelaDespesas.addColumn("Valor");
        tabelaDespesas.addColumn("Data");
        tabelaDespesas.addColumn("Descrição");
        tabelaDespesas.addColumn("Parcelas");
        tabelaDespesas.addColumn("Status");
        tabelaDespesas.addColumn("Categoria");
        tabelaDespesas.addColumn("Forma de pagamento");

        table = new JTable(tabelaDespesas) {
		    @Override
		    public boolean isCellEditable(int row, int column) {
		        return false; // Impede a edição das células
		    }
		};
        
        // JTable com o DefaultTableModel
        table.setRowSorter(new TableRowSorter(tabelaDespesas));

        // JScrollPane para a JTable
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(10, 85, 671, 350);
        add(scrollPane);
        
        // Renderizador personalizado para centralizar as colunas
        CentralizedTableCellRenderer renderer = new CentralizedTableCellRenderer();
        
        table.getColumnModel().getColumn(0).setCellRenderer(renderer); // Ajuste o índice da coluna conforme necessário
        table.getColumnModel().getColumn(1).setCellRenderer(renderer);
        table.getColumnModel().getColumn(2).setCellRenderer(renderer);
        table.getColumnModel().getColumn(3).setCellRenderer(renderer);
        table.getColumnModel().getColumn(4).setCellRenderer(renderer);
        table.getColumnModel().getColumn(5).setCellRenderer(renderer);
        table.getColumnModel().getColumn(6).setCellRenderer(renderer);
        table.getColumnModel().getColumn(7).setCellRenderer(renderer);
          
        table.getColumnModel().getColumn(0).setPreferredWidth(75); // Tamanho da coluna em pixel
        table.getColumnModel().getColumn(1).setPreferredWidth(100);
        table.getColumnModel().getColumn(2).setPreferredWidth(100);
        table.getColumnModel().getColumn(3).setPreferredWidth(100); 
        table.getColumnModel().getColumn(4).setPreferredWidth(75);
        table.getColumnModel().getColumn(5).setPreferredWidth(100);
        table.getColumnModel().getColumn(6).setPreferredWidth(100); 
        table.getColumnModel().getColumn(7).setPreferredWidth(175);
        
        
        carregarDespesas(usu);
        
        // Mudar cor do cabeçalho, fonte e centralizar texto
        JTableHeader header = table.getTableHeader();     
        header.setDefaultRenderer(new CustomHeaderRenderer());
        
        ImageIcon imageIcon3 =new ImageIcon(TelaReceita.class.getResource("/Icons/icon_add.png"));
		Image imagemOriginal3 = imageIcon3.getImage();
		// Redimensiona a imagem para as dimensões desejadas
		Image imagemRedimensionada3 = imagemOriginal3.getScaledInstance(18, 18, Image.SCALE_SMOOTH);
		// Cria um novo ImageIcon com a imagem redimensionada
		ImageIcon adicionar = new ImageIcon(imagemRedimensionada3);
		
        JLabel lblAdd = new JLabel(adicionar);
        lblAdd.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        lblAdd.setBounds(619, 39, 34, 30);
        add(lblAdd);
        
        // Botão para adicionar receita
        RoundedButton btnAdd = new RoundedButton("", 25);
        btnAdd.setBorder(null);
        btnAdd.setForeground(new Color(255, 255, 255));
        btnAdd.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		TelaDespesaNova recNova = new TelaDespesaNova(usu);
        		recNova.setVisible(true);
        		recNova.setLocationRelativeTo(null);
        		
        	}
        });
        btnAdd.setBounds(619, 40, 35, 30);
        btnAdd.setBackground(new Color(40, 66, 159));
        add(btnAdd);
        
		ImageIcon imageIcon =new ImageIcon(TelaReceita.class.getResource("/Icons/icon_lixeira.png"));
		Image imagemOriginal = imageIcon.getImage();
		// Redimensiona a imagem para as dimensões desejadas
		Image imagemRedimensionada = imagemOriginal.getScaledInstance(20, 20, Image.SCALE_SMOOTH);
		// Cria um novo ImageIcon com a imagem redimensionada
		ImageIcon lixeira = new ImageIcon(imagemRedimensionada);
		
        JLabel lblLixeira = new JLabel(lixeira);
        lblLixeira.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        lblLixeira.setBounds(567, 39, 34, 30);
        add(lblLixeira);
        
        // Botão para excluir receita
        RoundedButton btnExcluir = new RoundedButton("", 25);
        btnExcluir.setBorder(null);
        btnExcluir.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		 int selectedRow = table.getSelectedRow();
        	        if (selectedRow >= 0) {
        	            int idDespesa = (int) tabelaDespesas.getValueAt(selectedRow, 0);
        	            DespesasDAO despesaDAO = new DespesasDAO();
                        int resposta = despesaDAO.excluirDespesa(idDespesa);
                        if(resposta == 1) {
                        	tabelaDespesas.removeRow(selectedRow);
                        }                  
        	        } else {
        	            JOptionPane.showMessageDialog(null, "Selecione uma receita para excluir.");
        	        }
        	}
        });
        btnExcluir.setLayout(new BorderLayout());
        btnExcluir.setForeground(Color.WHITE);
        btnExcluir.setBackground(new Color(40, 66, 159));
        btnExcluir.setBounds(567, 40, 35, 30);
        add(btnExcluir);
        
        ImageIcon imageIcon2 = new ImageIcon(TelaReceita.class.getResource("/Icons/editar.png"));
		Image imagemOriginal2 = imageIcon2.getImage();
		// Redimensiona a imagem para as dimensões desejadas
		Image imagemRedimensionada2 = imagemOriginal2.getScaledInstance(19, 19, Image.SCALE_SMOOTH);
		// Cria um novo ImageIcon com a imagem redimensionada
		ImageIcon editar = new ImageIcon(imagemRedimensionada2);
		
        JLabel lblPincel = new JLabel(editar);
        lblPincel.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        lblPincel.setBounds(512, 39, 35, 30);
        add(lblPincel);
        
        // Botão para editar despesa
        RoundedButton btnEditar = new RoundedButton("", 25);
        btnEditar.setBorder(null);
        btnEditar.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		 int selectedRow = table.getSelectedRow();
        	        if (selectedRow >= 0) {
        	        	despesa.setId((int) tabelaDespesas.getValueAt(selectedRow, 0));
                    	despesa.setValor((double) tabelaDespesas.getValueAt(selectedRow, 1));
                    	String dataString = (String) tabelaDespesas.getValueAt(selectedRow, 2);
    					SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
    					try {
    						Date dateValue = dateFormat.parse(dataString);
    						despesa.setData(dateValue);
    						System.out.println("Data formatada: " + dateFormat.format(dateValue));
    					} catch (ParseException a) {
    						a.printStackTrace();
    					}
                    	despesa.setDescricao((String)tabelaDespesas.getValueAt(selectedRow, 3));
                    	despesa.setNumeroDeParcelas((int)tabelaDespesas.getValueAt(selectedRow, 4));
                    	if(tabelaDespesas.getValueAt(selectedRow, 5).equals("Sim")) {
                    		despesa.setPago(true);
                    	} else if (tabelaDespesas.getValueAt(selectedRow, 5).equals("Não")) {
                    		despesa.setPago(false);
                    	}
                    	despesa.setCategoria((String)tabelaDespesas.getValueAt(selectedRow, 6));
                    	despesa.setFormaDePagamento((String)tabelaDespesas.getValueAt(selectedRow, 7));
                    	
                    	TelaEditarDespesa despesaEdit = new TelaEditarDespesa(despesa, usu, TelaDespesa.this);
                    	despesaEdit.setVisible(true);
                    	despesaEdit.setLocationRelativeTo(null);
                	} else {
        	            JOptionPane.showMessageDialog(null, "Selecione uma despesa para editar.");
        	        }
        	    
        	}
        });
       
        btnEditar.setForeground(Color.WHITE);
        btnEditar.setBackground(new Color(40, 66, 159));
        btnEditar.setBounds(513, 40, 35, 30);
        add(btnEditar);
	}

	public void carregarDespesas(Usuario usuario) {
		// Limpa a tabela antes de adicionar novos dados
		DefaultTableModel model = (DefaultTableModel) table.getModel();
		model.setRowCount(0);

		// Obtém a lista de receitas do usuário
		DespesasDAO despesaDAO = new DespesasDAO();

		List<Despesa> despesas = despesaDAO.ListarDespesas(usuario);

		// Adiciona as receitas à tabela
		for (Despesa despesa : despesas) {
			String data = dataFormat.format(despesa.getData());
			String pago = "Não";
			if(despesa.isPago()) {
				pago = "Sim";
			} else {
				pago = "Não";
			}
			model.addRow(new Object[] { despesa.getId(), despesa.getValor(), data, despesa.getDescricao(), despesa.getNumeroDeParcelas(), 
					pago, despesa.getCategoria(), despesa.getFormaDePagamento()});
		}
	}
}

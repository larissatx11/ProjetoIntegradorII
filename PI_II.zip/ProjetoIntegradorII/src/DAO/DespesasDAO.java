package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

import Classes.Despesa;
import Classes.Receita;
import Classes.Usuario;
import Conexao.ModuloConexao;

public class DespesasDAO {
	Connection conexao = null;
	PreparedStatement pst = null;
	ResultSet rs = null;
	int idGerado;
	
	public int cadastrar(Despesa despesa) {
		conexao = ModuloConexao.conector();
		String sql = "insert into despesa (usuario_id, valor, data, descricao, categoria, forma_de_pagamento, numero_de_parcelas) values (?,?,?,?,?,?,?)";
			try {
				pst = conexao.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS);
				
				pst.setInt(1, despesa.getUsuario_id());
				pst.setDouble(2, despesa.getValor());
				java.sql.Date sqlDate = new java.sql.Date(despesa.getData().getTime());
				pst.setDate(3, sqlDate);
				pst.setString(4, despesa.getDescricao());
				pst.setString(5, despesa.getCategoria());
				pst.setString(6, despesa.getFormaDePagamento());
				pst.setInt(7, despesa.getNumeroDeParcelas());

				int rowsAffected = pst.executeUpdate();
				if (rowsAffected > 0) {
					// Obtém as chaves geradas automaticamente
					ResultSet generatedKeys = pst.getGeneratedKeys();
					if (generatedKeys.next()) {
						idGerado = generatedKeys.getInt(1); // Obtém o ID gerado
					}
					JOptionPane.showMessageDialog(null, "Despesa cadastrado com sucesso!");
				} else {
					JOptionPane.showMessageDialog(null, "Falha ao cadastrar a despesa.");
				}
			} catch (SQLException e) {
				System.out.println(e);
				JOptionPane.showMessageDialog(null, "Erro ao cadastrar a despesa: " + e.getMessage());
			}
		return idGerado; // Retorna o ID gerado ou -1 em caso de erro
	}
	
	public List<Despesa> ListarDespesas(Usuario usuario) {
		List<Despesa> despesas = new ArrayList<>();

		String sql = "SELECT * FROM despesa WHERE usuario_id = ?";

		try {
			Connection conexao = ModuloConexao.conector();
			PreparedStatement pst = conexao.prepareStatement(sql);
			pst.setInt(1, usuario.getId()); // ID do usuário atual
			ResultSet rs = pst.executeQuery();

			while (rs.next()) {		
				// Cria um objeto Receita com os dados do banco de dados
				Despesa despesa = new Despesa();
				despesa.setId(rs.getInt("id"));
				despesa.setUsuario_id(usuario.getId());
				despesa.setValor(rs.getDouble("valor"));
				despesa.setData(rs.getDate("data"));
				despesa.setDescricao(rs.getString("descricao"));
				despesa.setCategoria(rs.getString("categoria"));
				despesa.setFormaDePagamento(rs.getString("forma_de_pagamento"));
				despesa.setNumeroDeParcelas(rs.getInt("numero_de_parcelas"));
				despesa.setPago(rs.getBoolean("pago"));
				despesas.add(despesa);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return despesas;
	}
	
	public int excluirDespesa(int idDespesa) {
		conexao = ModuloConexao.conector();
		String sql = "DELETE FROM despesa WHERE id = ?";
		try {
			pst = conexao.prepareStatement(sql);
			pst.setInt(1, idDespesa);
			int excluir = JOptionPane.showConfirmDialog(null, "Tem certeza que deseja excluir a Despesa?", "Atenção",
					JOptionPane.YES_NO_OPTION);
			if (excluir == JOptionPane.YES_OPTION) {
				pst.executeUpdate();
				JOptionPane.showMessageDialog(null, "Despesa excluída com sucesso!");
				return 1;
			}
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "Erro ao excluir receita: " + e.getMessage());
		}
		return 0;
	}
	
	public void atualizarDespesa(Despesa despesa) {
		conexao = ModuloConexao.conector();
		String query = "UPDATE despesa SET valor=?, mes=? WHERE id=?"; // Usa a coluna "id" para identificar a receita

		try {
			pst = conexao.prepareStatement(query);
			pst.setDouble(1, despesa.getValor());

			// Converta a data de java.util.Date para java.sql.Date
			java.sql.Date sqlDate = new java.sql.Date(rec.getMes().getTime());
			pst.setDate(2, sqlDate);
			pst.setInt(3, rec.getId()); // Usa o ID da receita para identificar o registro a ser atualizado

			int rowsUpdated = pst.executeUpdate();
			if (rowsUpdated > 0) {
				JOptionPane.showMessageDialog(null, "Informações atualizadas com sucesso!");
			} else {
				JOptionPane.showMessageDialog(null, "Nenhum registro foi atualizado.");
			}
		} catch (SQLException e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, "Erro ao atualizar informações da receita: " + e.getMessage());
		}
	}
}

package Telas;

import java.awt.Choice;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.List;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import Classes.Cartao;
import Classes.Usuario;
import DAO.CartoesDAO;
import Swing.RoundedButton;

public class TelaEditarCartao extends JFrame {

	private JPanel contentPane;
	private JTextField txtNumero;
	private JTextField txtLimite;
	private JTextField txtFechamento;
	private TelaCartoes telaCartoes;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Cartao c = new Cartao();
					Usuario usu = new Usuario();
					TelaCartoes telaCartoes = new TelaCartoes(usu);
					TelaEditarCartao frame = new TelaEditarCartao(c, usu, telaCartoes);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public TelaEditarCartao(Cartao cartao, Usuario usu, TelaCartoes telaCartoes) {
		this.telaCartoes = telaCartoes;
		setTitle("Adicionar cartão");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 270, 348);
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 255, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblNewLabel = new JLabel("Número");
		lblNewLabel.setFont(new Font("Century Gothic", Font.PLAIN, 11));
		lblNewLabel.setBounds(37, 30, 46, 14);
		contentPane.add(lblNewLabel);

		JLabel lblNewLabel_1 = new JLabel("Limite");
		lblNewLabel_1.setFont(new Font("Century Gothic", Font.PLAIN, 11));
		lblNewLabel_1.setBounds(37, 76, 46, 14);
		contentPane.add(lblNewLabel_1);

		JLabel lblNewLabel_2 = new JLabel("Fechamento");
		lblNewLabel_2.setFont(new Font("Century Gothic", Font.PLAIN, 11));
		lblNewLabel_2.setBounds(37, 122, 81, 14);
		contentPane.add(lblNewLabel_2);

		JLabel lblNewLabel_3 = new JLabel("Tipo");
		lblNewLabel_3.setFont(new Font("Century Gothic", Font.PLAIN, 11));
		lblNewLabel_3.setBounds(37, 171, 46, 14);
		contentPane.add(lblNewLabel_3);

		JLabel lblNewLabel_4 = new JLabel("Bandeira");
		lblNewLabel_4.setFont(new Font("Century Gothic", Font.PLAIN, 11));
		lblNewLabel_4.setBounds(37, 215, 67, 14);
		contentPane.add(lblNewLabel_4);

		txtNumero = new JTextField(String.valueOf(cartao.getNumero()));
		txtNumero.setBounds(37, 45, 181, 20);
		contentPane.add(txtNumero);
		txtNumero.setColumns(10);

		txtLimite = new JTextField(String.valueOf(cartao.getLimite()));
		txtLimite.setBounds(37, 91, 181, 20);
		contentPane.add(txtLimite);
		txtLimite.setColumns(10);

		txtFechamento = new JTextField(String.valueOf(cartao.getFechamento()));
		txtFechamento.setBounds(37, 138, 181, 20);
		contentPane.add(txtFechamento);
		txtFechamento.setColumns(10);

		// Criar escolhas (Choice) para "Tipo" e "Bandeira" e adicionar opções
		Choice choiceBandeira = new Choice();
		choiceBandeira.setBounds(37, 230, 181, 20);
		choiceBandeira.add(cartao.getBandeira());
		choiceBandeira.add("Visa");
		choiceBandeira.add("MasterCard");
		choiceBandeira.add("American Express");
		choiceBandeira.add("Elo");
		choiceBandeira.addItemListener((ItemListener) new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (choiceBandeira.getSelectedItem().equals("Selecione")) {
					System.out.println("Bandeira de cartão inválida");
				} else if (choiceBandeira.getSelectedItem().equals("Visa")) {
					cartao.setBandeira("Visa");
				} else if (choiceBandeira.getSelectedItem().equals("MasterCard")) {
					cartao.setBandeira("MasterCard");
				}else if (choiceBandeira.getSelectedItem().equals("American Express")) {
					cartao.setBandeira("American Express");
				}else if (choiceBandeira.getSelectedItem().equals("Elo")) {
					cartao.setBandeira("Elo");
				}
			}
		});

		contentPane.add(choiceBandeira);

		Choice choiceTipo = new Choice();
		choiceTipo.setBounds(37, 187, 181, 20);
		choiceTipo.add(cartao.getTipo());
		choiceTipo.add("Débito");
		choiceTipo.add("Crédito");
		choiceTipo.addItemListener((ItemListener) new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (choiceTipo.getSelectedItem().equals("Selecione")) {
					System.out.println("Tipo de cartão inválido");
				} else if (choiceTipo.getSelectedItem().equals("Débito")) {
					cartao.setTipo("Débito");
				} else if (choiceTipo.getSelectedItem().equals("Crédito")) {
					cartao.setTipo("Crédito");
				}
			}
		});
		contentPane.add(choiceTipo);

		// Botão para salvar as alterações
		RoundedButton btnEditar = new RoundedButton("Salvar", 20);
		btnEditar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				// Obtém os novos valores dos campos de texto
				Long novoNumero = Long.parseLong(txtNumero.getText());
				Double novoLimite = Double.parseDouble(txtLimite.getText());
				int novoFechamento = Integer.parseInt(txtFechamento.getText());
				String novaBandeira = choiceBandeira.getSelectedItem();
				String novoTipo = choiceTipo.getSelectedItem();
				
				// Atualiza os atributos do cartao
				cartao.setNumero(novoNumero);
				cartao.setLimite(novoLimite);
				cartao.setFechamento(novoFechamento);
				cartao.setBandeira(novaBandeira);
				cartao.setTipo(novoTipo); // caso mude de crédito para débito e vice versa, precisa mudar os campos de valor_atual, fechamento e limite
				cartao.setUsuario_id(usu.getId());
				cartao.setValor_atual(usu.getSaldo());
				
				// Executa a lógica para salvar o cartao atualizado no banco de dados
				CartoesDAO cartaoDAO = new CartoesDAO();
				cartaoDAO.atualizarCartao(cartao);

				// Atualiza as informações na tabela
				List<Cartao> cartoesAtualizados = cartaoDAO.ListarCartoes(usu);
				telaCartoes.atualizarTabela(cartoesAtualizados);

				dispose();
			}
		});
		btnEditar.setForeground(Color.WHITE);
		btnEditar.setFont(new Font("Yu Gothic UI", Font.BOLD, 12));
		btnEditar.setBorder(null);
		btnEditar.setBackground(new Color(40, 66, 159));
		btnEditar.setBounds(87, 270, 89, 23);
		contentPane.add(btnEditar);
	
	}

}

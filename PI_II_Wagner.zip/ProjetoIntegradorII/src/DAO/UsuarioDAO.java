package DAO;

import java.awt.Image;
import java.io.File;
import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileNameExtensionFilter;

import Classes.Usuario;
import Conexao.ModuloConexao;
import Telas.TelaCadastro;
import Telas.TelaLogin;
import Telas.TelaPrincipal;

public class UsuarioDAO {

	Connection conexao = null;
	PreparedStatement pst = null;
	ResultSet rs = null;
	
	public void cadastrar(Usuario usu) {
		conexao = ModuloConexao.conector();
		String sql = "insert into usuario(nome, email, senha) values(?,?,?)";
		try {
			pst = conexao.prepareStatement(sql);
			pst.setString(1, usu.getNome());
			pst.setString(2, usu.getEmail());
			pst.setString(3, usu.getSenha());
			pst.executeUpdate();
			JOptionPane.showMessageDialog(null, "Usuário cadastrado com sucesso!");
			TelaLogin login = new TelaLogin();
			login.setVisible(true);
			login.setLocationRelativeTo(null);
		} catch (SQLException e){
			JOptionPane.showMessageDialog(null, e);
		}
	}
	
	public void logar(Usuario usu) {
		conexao = ModuloConexao.conector();
		String sql = "select * from usuario where email =? and senha =?";
		try {
			pst = conexao.prepareStatement(sql);
			pst.setString(1, usu.getEmail());
			String captura = new String(usu.getSenha());
			pst.setString(2, captura);
			rs = pst.executeQuery();
			if(rs.next()) {
				usu.setNome(rs.getString("nome"));
				TelaPrincipal principal = new TelaPrincipal(usu);
				principal.setVisible(true);
				principal.setLocationRelativeTo(null);
				conexao.close();
			} else {
				JOptionPane.showMessageDialog(null, "Usuário e/ou senha inválidos");
			}
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e);
		}
	}
	
	public void selecionarFoto(TelaCadastro cad) {
		JFileChooser arquivo = new JFileChooser();
		arquivo.setDialogTitle("SELECIONE UMA IMAGEM");
		arquivo.setFileFilter(
				new FileNameExtensionFilter("Arquivo de imagens(*.PNG, *.JPG, *.JPEG)", "png", "jpg", "jpeg"));
		// a linha abaixo seleciona apenas uma imagem
		arquivo.setFileSelectionMode(JFileChooser.FILES_ONLY);
		int op = arquivo.showOpenDialog(null);
		if (op == JFileChooser.APPROVE_OPTION) {
			File selectedFile = arquivo.getSelectedFile();
			cad.txtFoto.setText(selectedFile.getAbsolutePath());
			ImageIcon imageIcon = new ImageIcon(selectedFile.getAbsolutePath());
			Image image = imageIcon.getImage().getScaledInstance(155, 135, Image.SCALE_DEFAULT);
			imageIcon = new ImageIcon(image);
			cad.lblCamera.setIcon(imageIcon);

		} else if (op == JFileChooser.CANCEL_OPTION) {
			System.out.println("No Data");
		}
	
	}
}

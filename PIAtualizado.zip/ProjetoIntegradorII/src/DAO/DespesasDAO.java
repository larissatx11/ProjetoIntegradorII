package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

import Classes.Despesa;
import Classes.Receita;
import Classes.Usuario;
import Conexao.ModuloConexao;

public class DespesasDAO {
	Connection conexao = null;
	PreparedStatement pst = null;
	ResultSet rs = null;
	int idGerado;
	int rowsAffected;
	UsuarioDAO usuarioDAO = new UsuarioDAO();
	
	public int verificarSaldo(Despesa despesa, Usuario usu) {
		if(despesa.getFormaDePagamento() == "Débito" || despesa.getFormaDePagamento() == "Dinheiro") {
			System.out.println("Lalissa Gostosa: "+despesa.getValor());
			if(despesa.getValor() <= usu.getSaldo()) {
				usuarioDAO.atualizaSaldo(usuarioDAO.subtraiSaldo(usu, despesa.getValor()));
				cadastrar(despesa, usu);
			} else {
				JOptionPane.showMessageDialog(null, "Saldo insuficiente!");
				return -1;
			}
		}
		return -1;
	}
	
	public int cadastrar(Despesa despesa, Usuario usu) {
		conexao = ModuloConexao.conector();
		int idGerado = -1; // Inicialize o ID como -1 (em caso de erro)
		String sql = "insert into despesa (usuario_id, valor, data, descricao, categoria, forma_de_pagamento, cartao, numero_de_parcelas) values (?,?,?,?,?,?,?,?)";
			try {
				pst = conexao.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS);
				
				pst.setInt(1, despesa.getUsuario_id());
				pst.setDouble(2, despesa.getValor());
				java.sql.Date sqlDate = new java.sql.Date(despesa.getData().getTime());
				pst.setDate(3, sqlDate);
				pst.setString(4, despesa.getDescricao());
				pst.setString(5, despesa.getCategoria());
				pst.setString(6, despesa.getFormaDePagamento());
				pst.setString(7, despesa.getCartao());
				pst.setInt(8, despesa.getNumeroDeParcelas());

				if(usu.getSaldo() >= despesa.getValor()) {
					rowsAffected = pst.executeUpdate();
				} else {
					JOptionPane.showMessageDialog(null, "Saldo insuficiente!");
					return -1;
				}
				
				if (rowsAffected > 0) {
					// Obtém as chaves geradas automaticamente
					ResultSet generatedKeys = pst.getGeneratedKeys();
					if (generatedKeys.next()) {
						idGerado = generatedKeys.getInt(1); // Obtém o ID gerado
					}
					JOptionPane.showMessageDialog(null, "Despesa cadastrado com sucesso!");
				} else {
					JOptionPane.showMessageDialog(null, "Falha ao cadastrar a despesa.");
				}
			} catch (SQLException e) {
				System.out.println(e);
				JOptionPane.showMessageDialog(null, "Erro ao cadastrar a despesa: " + e.getMessage());
			}
		return idGerado; // Retorna o ID gerado ou -1 em caso de erro
	}
	
	public void atualizarDespesa(Despesa despesa, Usuario usu) {
		conexao = ModuloConexao.conector();
		String query = "UPDATE despesa SET usuario_id=?, categoria=?, valor=?, data=?, forma_de_pagamento=?, cartao=?,"
				+ " numero_de_parcelas=?, descricao=? WHERE id=?"; // Usa a coluna "id" para identificar a receita

		try {
			pst = conexao.prepareStatement(query);
			pst.setInt(1, despesa.getUsuario_id());
			pst.setString(2, despesa.getCategoria());
			pst.setDouble(3, despesa.getValor());
			java.sql.Date sqlDate = new java.sql.Date(despesa.getData().getTime());
			pst.setDate(4, sqlDate);
			pst.setString(5, despesa.getFormaDePagamento());
			pst.setString(6, despesa.getCartao());
			pst.setInt(7, despesa.getNumeroDeParcelas());
			pst.setString(8, despesa.getDescricao());
			pst.setInt(9, despesa.getId()); // Usa o ID da despesa para identificar o registro a ser atualizado
			System.out.println(despesa.getId());
			int rowsUpdated = pst.executeUpdate();
			if (rowsUpdated > 0) {
				usuarioDAO.subtraiSaldo(usu, despesa.getValor());
				JOptionPane.showMessageDialog(null, "Informações atualizadas com sucesso!");
				usuarioDAO.atualizaSaldo(usu);
			} else {
				JOptionPane.showMessageDialog(null, "Nenhum registro foi atualizado.");
			}
		} catch (SQLException e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, "Erro ao atualizar informações da despesa: " + e.getMessage());
		}
	}
	
	public int excluirDespesa(Despesa despesa, Usuario usu) {
		conexao = ModuloConexao.conector();
		String sql = "DELETE FROM despesa WHERE id = ?";
		try {
			pst = conexao.prepareStatement(sql);
			pst.setInt(1, despesa.getId());
			int excluir = JOptionPane.showConfirmDialog(null, "Tem certeza que deseja excluir a Despesa?", "Atenção",
					JOptionPane.YES_NO_OPTION);
			if (excluir == JOptionPane.YES_OPTION) {
				pst.executeUpdate();
				usuarioDAO.atualizaSaldo(usuarioDAO.somaSaldo(usu, despesa.getValor()));
				JOptionPane.showMessageDialog(null, "Despesa excluída com sucesso!");
				return 1;
			}
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "Erro ao excluir receita: " + e.getMessage());
		}
		return 0;
	}
	
	public List<Despesa> ListarDespesas(Usuario usuario) {
		List<Despesa> despesas = new ArrayList<>();

		String sql = "SELECT * FROM despesa WHERE usuario_id = ?";

		try {
			Connection conexao = ModuloConexao.conector();
			PreparedStatement pst = conexao.prepareStatement(sql);
			pst.setInt(1, usuario.getId()); // ID do usuário atual
			ResultSet rs = pst.executeQuery();

			while (rs.next()) {		
				// Cria um objeto Receita com os dados do banco de dados
				Despesa despesa = new Despesa();
				despesa.setId(rs.getInt("id"));
				despesa.setUsuario_id(usuario.getId());
				despesa.setValor(rs.getDouble("valor"));
				despesa.setData(rs.getDate("data"));
				despesa.setDescricao(rs.getString("descricao"));
				despesa.setCategoria(rs.getString("categoria"));
				despesa.setFormaDePagamento(rs.getString("forma_de_pagamento"));
				despesa.setCartao(rs.getString("cartao"));
				despesa.setNumeroDeParcelas(rs.getInt("numero_de_parcelas"));
				despesa.setPago(rs.getBoolean("pago"));
				despesas.add(despesa);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return despesas;
	}
	
}

package Telas;
import javax.swing.JPanel;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;

import javax.swing.SwingConstants;

public class TelaHome extends JPanel {

	/**
	 * Create the panel.
	 */
	public TelaHome() {
		setBounds(0, 0, 691, 498);
		setLayout(null);
		setVisible(true);
		setBackground(Color.WHITE);
		
		JLabel lblNewLabel = new JLabel("Home");
		lblNewLabel.setFont(new Font("Century Gothic", Font.BOLD, 30));
		lblNewLabel.setForeground(new Color(40, 66, 159));
		lblNewLabel.setBounds(28, 0, 142, 85);
		add(lblNewLabel);
		
		ImageIcon imageIcon = new ImageIcon(TelaHome.class.getResource("/Icons/calculadora.png"));
		Image imagemOriginal = imageIcon.getImage();
		// Redimensiona a imagem para as dimensões desejadas
		Image imagemRedimensionada = imagemOriginal.getScaledInstance(600, 450, Image.SCALE_SMOOTH);
		// Cria um novo ImageIcon com a imagem redimensionada
		ImageIcon imagem = new ImageIcon(imagemRedimensionada);
		
		JLabel lblNewLabel_1 = new JLabel(imagem);
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setBounds(72, 52, 588, 347);
		add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Domine suas finanças, liberte seu futuro.");
		lblNewLabel_2.setForeground(new Color(40, 66, 159));
		lblNewLabel_2.setFont(new Font("Century Gothic", Font.PLAIN, 16));
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setBounds(133, 410, 412, 22);
		add(lblNewLabel_2);
	}
}

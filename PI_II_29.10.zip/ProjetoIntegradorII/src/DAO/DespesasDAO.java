package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JOptionPane;

import Classes.Cartao;
import Classes.Despesa;
import Conexao.ModuloConexao;

public class DespesasDAO {
	Connection conexao = null;
	PreparedStatement pst = null;
	ResultSet rs = null;
	int idGerado;
	
	public int cadastrar(Despesa despesa) {
		conexao = ModuloConexao.conector();
		String sql = "insert into despesa (usuario_id, valor, descricao, categoria, forma_de_pagamento, numero_de_parcelas) values (?,?,?,?,?,?)";
			try {
				pst = conexao.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS);
				
				pst.setInt(1, despesa.getUsuario_id());
				pst.setDouble(2, despesa.getValor());
				pst.setString(3, despesa.getDescricao());
				pst.setString(4, despesa.getCategoria());
				pst.setString(5, despesa.getFormaDePagamento());
				pst.setInt(6, despesa.getNumeroDeParcelas());

				int rowsAffected = pst.executeUpdate();
				if (rowsAffected > 0) {
					// Obtém as chaves geradas automaticamente
					ResultSet generatedKeys = pst.getGeneratedKeys();
					if (generatedKeys.next()) {
						idGerado = generatedKeys.getInt(1); // Obtém o ID gerado
					}
					JOptionPane.showMessageDialog(null, "Despesa cadastrado com sucesso!");
				} else {
					JOptionPane.showMessageDialog(null, "Falha ao cadastrar a despesa.");
				}
			} catch (SQLException e) {
				System.out.println(e);
				JOptionPane.showMessageDialog(null, "Erro ao cadastrar a despesa: " + e.getMessage());
			}
		return idGerado; // Retorna o ID gerado ou -1 em caso de erro
	}
}

package Telas;
import java.awt.Choice;
import java.awt.Color;
import java.awt.Font;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableRowSorter;

import Swing.CentralizedTableCellRenderer;
import Swing.CustomHeaderRenderer;

public class TelaFatura extends JPanel {
    private DefaultTableModel tableModel;
    private JTable table;
    private DefaultTableModel tableModel2;
    private JTable table2;
	/**
	 * Create the panel.
	 */
	public TelaFatura() {
		setBounds(0, 0, 691, 498);
		setLayout(null);
		setBackground(Color.WHITE);
		
		JLabel lblNewLabel = new JLabel("Fatura");
		lblNewLabel.setFont(new Font("Century Gothic", Font.BOLD, 30));
		lblNewLabel.setForeground(new Color(40, 66, 159));
		lblNewLabel.setBounds(28, 0, 142, 85);
		add(lblNewLabel);
		
		
		 // DefaultTableModel com as colunas id, valor e mês
       tableModel = new DefaultTableModel();
       tableModel.addColumn("ID");
       tableModel.addColumn("Forma de pagamento");
       tableModel.addColumn("Número");
       tableModel.addColumn("Limite");
       tableModel.addColumn("Valor da fatura");

       // JTable com o DefaultTableModel
       table = new JTable(tableModel);
       table.setRowSorter(new TableRowSorter(tableModel));
       
       // JScrollPane para a JTable
       JScrollPane scrollPane = new JScrollPane(table);
       scrollPane.setBounds(28, 85, 635, 67);
       add(scrollPane);
       
       // Renderizador personalizado para centralizar as colunas
       CentralizedTableCellRenderer renderer = new CentralizedTableCellRenderer();
       
       table.getColumnModel().getColumn(0).setCellRenderer(renderer); // Ajuste o índice da coluna conforme necessário
       table.getColumnModel().getColumn(1).setCellRenderer(renderer);
       table.getColumnModel().getColumn(2).setCellRenderer(renderer);
       table.getColumnModel().getColumn(3).setCellRenderer(renderer);
       table.getColumnModel().getColumn(4).setCellRenderer(renderer);
           
       // Mudar cor do cabeçalho, fonte e centralizar texto
       JTableHeader header = table.getTableHeader();     
       header.setDefaultRenderer(new CustomHeaderRenderer());
       
       // DefaultTableModel com as colunas id, valor e mês
       tableModel2 = new DefaultTableModel();
       tableModel2.addColumn("ID");
       tableModel2.addColumn("Valor");
       tableModel2.addColumn("Data");
       tableModel2.addColumn("Descrição");
       tableModel2.addColumn("Parcelas");
       tableModel2.addColumn("Status");
       tableModel2.addColumn("Categoria");

       // JTable com o DefaultTableModel
       table2 = new JTable(tableModel2);

       // JScrollPane para a JTable
       JScrollPane scrollPane2 = new JScrollPane(table2);
       scrollPane2.setBounds(28, 189, 635, 280);
       add(scrollPane2);
       
       Choice choice = new Choice();
       choice.setBounds(501, 39, 162, 20);
       add(choice);
       
       JLabel lblNewLabel_1 = new JLabel("Selecione o cartão");
       lblNewLabel_1.setFont(new Font("Century Gothic", Font.PLAIN, 12));
       lblNewLabel_1.setBounds(501, 19, 162, 14);
       add(lblNewLabel_1);
       
       JLabel lblNewLabel_2 = new JLabel("Informações do cartão");
       lblNewLabel_2.setFont(new Font("Century Gothic", Font.PLAIN, 12));
       lblNewLabel_2.setBounds(28, 69, 173, 14);
       add(lblNewLabel_2);
       
       JLabel lblNewLabel_2_1 = new JLabel("Resumo da fatura");
       lblNewLabel_2_1.setFont(new Font("Century Gothic", Font.PLAIN, 12));
       lblNewLabel_2_1.setBounds(28, 174, 173, 14);
       add(lblNewLabel_2_1);
       
       // Renderizador personalizado para centralizar as colunas
       CentralizedTableCellRenderer renderer2 = new CentralizedTableCellRenderer();
       
       table2.getColumnModel().getColumn(0).setCellRenderer(renderer2); // Ajuste o índice da coluna conforme necessário
       table2.getColumnModel().getColumn(1).setCellRenderer(renderer2);
       table2.getColumnModel().getColumn(2).setCellRenderer(renderer2);
       table2.getColumnModel().getColumn(3).setCellRenderer(renderer2);
       table2.getColumnModel().getColumn(4).setCellRenderer(renderer2);
       table2.getColumnModel().getColumn(5).setCellRenderer(renderer2);
           
       // Mudar cor do cabeçalho, fonte e centralizar texto
       JTableHeader header2 = table2.getTableHeader();     
       header2.setDefaultRenderer(new CustomHeaderRenderer());

		
	}

}

package Telas;
import javax.swing.JPanel;
import javax.swing.JLabel;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.table.DefaultTableModel;
import Classes.Usuario;
import Swing.RoundedButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class TelaReceita extends JPanel {
	
    private DefaultTableModel tableModel;
    private JTable table;
	/**
	 * Create the panel.
	 */
	public TelaReceita(Usuario usu) {
		setBounds(0, 0, 691, 498);
		setBackground(Color.WHITE);
		setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Receita");
		lblNewLabel.setBounds(28, 0, 142, 85);
		lblNewLabel.setFont(new Font("Century Gothic", Font.BOLD, 30));
		lblNewLabel.setForeground(new Color(40, 66, 159));
		add(lblNewLabel);
		
		 // Crie o DefaultTableModel com as colunas id, valor e mês
        tableModel = new DefaultTableModel();
        tableModel.addColumn("ID");
        tableModel.addColumn("Valor");
        tableModel.addColumn("Mês");

        // Crie a JTable com o DefaultTableModel
        table = new JTable(tableModel);

        // Crie um JScrollPane para a JTable
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(28, 85, 635, 350);
        add(scrollPane);
        
        RoundedButton btnNewButton = new RoundedButton("+", 25);
        btnNewButton.setForeground(new Color(255, 255, 255));
        btnNewButton.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		Usuario aux = new Usuario();
        		aux.setId(usu.getId());
        		TelaReceitaNova recNova = new TelaReceitaNova(aux, TelaReceita.this);
        		recNova.setVisible(true);
        		recNova.setLocationRelativeTo(null);
        	}
        });
        btnNewButton.setBounds(606, 40, 38, 28);
        btnNewButton.setBackground(new Color(40, 66, 159));
        add(btnNewButton);
	}
	 // Método para adicionar uma nova receita à tabela
    public void adicionarReceita(int id, double valor, int mes) {
        // Adicione uma nova linha à tabela com os dados da receita
        tableModel.addRow(new Object[]{id, valor, mes});
    }
}
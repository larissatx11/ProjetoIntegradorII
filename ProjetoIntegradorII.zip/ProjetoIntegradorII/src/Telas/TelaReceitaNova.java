package Telas;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Classes.Receita;
import Classes.Usuario;
import DAO.ReceitaDAO;
import DAO.UsuarioDAO;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class TelaReceitaNova extends JFrame {

	private JPanel contentPane;
	private JTextField txtValor;
	private JTextField txtMes;
	private TelaReceita telaReceita;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Usuario usu = new Usuario();
					TelaReceita telaReceita = new TelaReceita(usu);
					TelaReceitaNova frame = new TelaReceitaNova(usu, telaReceita);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */

	public TelaReceitaNova(Usuario usu, TelaReceita telaReceita) {
		this.telaReceita = telaReceita;
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 296, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblValor = new JLabel("Valor:");
		lblValor.setBounds(41, 76, 46, 14);
		contentPane.add(lblValor);
		
		JLabel lblMes = new JLabel("Mês:");
		lblMes.setBounds(41, 148, 46, 14);
		contentPane.add(lblMes);
		
		txtValor = new JTextField();
		txtValor.setBounds(81, 73, 156, 20);
		contentPane.add(txtValor);
		txtValor.setColumns(10);
		
		txtMes = new JTextField();
		txtMes.setBounds(81, 145, 156, 20);
		contentPane.add(txtMes);
		txtMes.setColumns(10);
		
		JButton btnADD = new JButton("Adicionar");
		btnADD.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 Receita rec = new Receita();
			        rec.setValor(Float.parseFloat(txtValor.getText()));
			        rec.setMes(Integer.parseInt(txtMes.getText()));
			        rec.setId(usu.getId());
			        ReceitaDAO chama = new ReceitaDAO();
			        int idGerado = chama.cadastrar(rec, usu);
			        if (idGerado != -1) {
			            // O cadastro foi bem-sucedido, e você tem o ID gerado em idGerado
			            System.out.println("ID da receita: " + idGerado);
			            rec.setId(idGerado);
			            telaReceita.adicionarReceita(idGerado, rec.getValor(), rec.getMes());

			        } else {
			            // O cadastro falhou
			        }
			       // TelaReceita telaReceita = new TelaReceita(usu);
			       // telaReceita.adicionarReceita(idGerado, rec.getValor(), rec.getMes());
			        dispose();
			    }
			});
		btnADD.setBounds(97, 208, 89, 23);
		contentPane.add(btnADD);
	}
}

package Telas;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;

import Classes.Receita;
import Classes.Usuario;
import DAO.ReceitaDAO;
import Swing.CentralizedTableCellRenderer;
import Swing.CustomHeaderRenderer;
import Swing.RoundedButton;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TelaDespesas extends JPanel {
    private DefaultTableModel tableModel;
    private JTable table;
	/**
	 * Create the panel.
	 */
	public TelaDespesas() {
		setBounds(0, 0, 691, 498);
		setLayout(null);
		setBackground(Color.WHITE);
		
		JLabel lblNewLabel = new JLabel("Despesas");
		lblNewLabel.setFont(new Font("Century Gothic", Font.BOLD, 30));
		lblNewLabel.setForeground(new Color(40, 66, 159));
		lblNewLabel.setBounds(28, 0, 142, 85);
		add(lblNewLabel);
		
		 // DefaultTableModel com as colunas id, valor e mês
        tableModel = new DefaultTableModel();
        tableModel.addColumn("ID");
        tableModel.addColumn("Valor");
        tableModel.addColumn("Data");
        tableModel.addColumn("Descrição");
        tableModel.addColumn("Parcelas");
        tableModel.addColumn("Status");
        tableModel.addColumn("Categoria");
        tableModel.addColumn("Forma de pagamento");

        // JTable com o DefaultTableModel
        table = new JTable(tableModel);

        // JScrollPane para a JTable
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(10, 85, 671, 350);
        add(scrollPane);
        
        // Renderizador personalizado para centralizar as colunas
        CentralizedTableCellRenderer renderer = new CentralizedTableCellRenderer();
        
        table.getColumnModel().getColumn(0).setCellRenderer(renderer); // Ajuste o índice da coluna conforme necessário
        table.getColumnModel().getColumn(1).setCellRenderer(renderer);
        table.getColumnModel().getColumn(2).setCellRenderer(renderer);
            
        // Mudar cor do cabeçalho, fonte e centralizar texto
        JTableHeader header = table.getTableHeader();     
        header.setDefaultRenderer(new CustomHeaderRenderer());
        
        ImageIcon imageIcon3 =new ImageIcon(TelaReceita.class.getResource("/Icons/icon_add.png"));
		Image imagemOriginal3 = imageIcon3.getImage();
		// Redimensiona a imagem para as dimensões desejadas
		Image imagemRedimensionada3 = imagemOriginal3.getScaledInstance(18, 18, Image.SCALE_SMOOTH);
		// Cria um novo ImageIcon com a imagem redimensionada
		ImageIcon adicionar = new ImageIcon(imagemRedimensionada3);
		
        JLabel lblAdd = new JLabel(adicionar);
        lblAdd.setBounds(619, 39, 34, 30);
        add(lblAdd);
        
        // Botão para adicionar receita
        RoundedButton btnAdd = new RoundedButton("", 25);
        btnAdd.setBorder(null);
        btnAdd.setForeground(new Color(255, 255, 255));
        btnAdd.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
//        		Usuario aux = new Usuario();
//        		aux.setId(usu.getId());
//        		TelaReceitaNova recNova = new TelaReceitaNova(aux, TelaReceita.this);
//        		recNova.setVisible(true);
//        		recNova.setLocationRelativeTo(null);
        	}
        });
        btnAdd.setBounds(619, 40, 35, 30);
        btnAdd.setBackground(new Color(40, 66, 159));
        add(btnAdd);
        
		ImageIcon imageIcon =new ImageIcon(TelaReceita.class.getResource("/Icons/icon_lixeira.png"));
		Image imagemOriginal = imageIcon.getImage();
		// Redimensiona a imagem para as dimensões desejadas
		Image imagemRedimensionada = imagemOriginal.getScaledInstance(20, 20, Image.SCALE_SMOOTH);
		// Cria um novo ImageIcon com a imagem redimensionada
		ImageIcon lixeira = new ImageIcon(imagemRedimensionada);
		
        JLabel lblLixeira = new JLabel(lixeira);
        lblLixeira.setBounds(567, 39, 34, 30);
        add(lblLixeira);
        
        // Botão para excluir receita
        RoundedButton btnExcluir = new RoundedButton("", 25);
        btnExcluir.setBorder(null);
        btnExcluir.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		 int selectedRow = table.getSelectedRow();
        	        if (selectedRow >= 0) {
//        	            int idReceita = (int) tableModel.getValueAt(selectedRow, 0); // Suponhamos que o ID esteja na coluna 0
//        	            ReceitaDAO receitaDAO = new ReceitaDAO();
//                        int resposta = receitaDAO.excluirReceita(idReceita);
//                        if(resposta == 0) {
//                        	 tableModel.removeRow(selectedRow);
//                        }                  
        	        } else {
        	            JOptionPane.showMessageDialog(null, "Selecione uma receita para excluir.");
        	        }
        	}
        });
        btnExcluir.setLayout(new BorderLayout());
        btnExcluir.setForeground(Color.WHITE);
        btnExcluir.setBackground(new Color(40, 66, 159));
        btnExcluir.setBounds(567, 40, 35, 30);
        add(btnExcluir);
        
        ImageIcon imageIcon2 = new ImageIcon(TelaReceita.class.getResource("/Icons/editar.png"));
		Image imagemOriginal2 = imageIcon2.getImage();
		// Redimensiona a imagem para as dimensões desejadas
		Image imagemRedimensionada2 = imagemOriginal2.getScaledInstance(19, 19, Image.SCALE_SMOOTH);
		// Cria um novo ImageIcon com a imagem redimensionada
		ImageIcon editar = new ImageIcon(imagemRedimensionada2);
		
        JLabel lblPincel = new JLabel(editar);
        lblPincel.setBounds(512, 39, 35, 30);
        add(lblPincel);
        
        // Botão para editar receita
        RoundedButton btnEditar = new RoundedButton("", 25);
        btnEditar.setBorder(null);
        btnEditar.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		 int selectedRow = table.getSelectedRow();
        	        if (selectedRow >= 0) {
//        	        	Receita receita = new Receita();
//        	            int idReceita = (int) tableModel.getValueAt(selectedRow, 0);
//                    	double valor = (double) tableModel.getValueAt(selectedRow, 1);
//                    	int mes = (int) tableModel.getValueAt(selectedRow, 2);
//                    	receita.setId(idReceita);
//                    	receita.setValor(valor);
//                    	receita.setMes(mes);
//                		TelaEditarReceita recEdit = new TelaEditarReceita(receita, usu, TelaReceita.this);
//                		recEdit.setVisible(true);
//                		recEdit.setLocationRelativeTo(null);
//                           	        
                		} else {
        	            JOptionPane.showMessageDialog(null, "Selecione uma receita para editar.");
        	        }
        	}
        });
       
        btnEditar.setForeground(Color.WHITE);
        btnEditar.setBackground(new Color(40, 66, 159));
        btnEditar.setBounds(513, 40, 35, 30);
        add(btnEditar);
	}

}

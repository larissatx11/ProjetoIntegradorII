package Telas;
import java.awt.Color;
import java.awt.Font;

import javax.swing.JLabel;
import javax.swing.JPanel;

public class TelaCategoria extends JPanel {

	/**
	 * Create the panel.
	 */
	public TelaCategoria() {
		setBounds(0, 0, 691, 498);
		setLayout(null);
		setBackground(Color.WHITE);
		
		JLabel lblNewLabel = new JLabel("Categoria");
		lblNewLabel.setFont(new Font("Century Gothic", Font.BOLD, 30));
		lblNewLabel.setForeground(new Color(40, 66, 159));
		lblNewLabel.setBounds(28, 0, 188, 85);
		add(lblNewLabel);
	}

}

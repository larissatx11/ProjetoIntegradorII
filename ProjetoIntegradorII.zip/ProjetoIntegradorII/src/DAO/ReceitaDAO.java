package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

import com.mysql.cj.xdevapi.Statement;

import Classes.Receita;
import Classes.Usuario;
import Conexao.ModuloConexao;
import Telas.TelaLogin;
import Telas.TelaReceita;

public class ReceitaDAO {

	Connection conexao = null;
	PreparedStatement pst = null;
	ResultSet rs = null;
	
	public int cadastrar(Receita rec, Usuario usu) {
	    conexao = ModuloConexao.conector();
	    String sql = "insert into receita(valor, mes, usuario_id) values(?,?,?)";
	    int idGerado = -1; // Inicialize o ID como -1 (em caso de erro)
	    try {
	        pst = conexao.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS);
	        pst.setFloat(1, rec.getValor());
	        pst.setInt(2, rec.getMes());
	        pst.setInt(3, usu.getId());
	        
	        int rowsAffected = pst.executeUpdate();
	        if (rowsAffected > 0) {
	            // Obtém as chaves geradas automaticamente
	            ResultSet generatedKeys = pst.getGeneratedKeys();
	            if (generatedKeys.next()) {
	                idGerado = generatedKeys.getInt(1); // Obtém o ID gerado
	            }
	            JOptionPane.showMessageDialog(null, "Receita cadastrada com sucesso!");
	        } else {
	            JOptionPane.showMessageDialog(null, "Falha ao cadastrar a receita.");
	        }
	    } catch (SQLException e) {
	        System.out.println(e);
	        JOptionPane.showMessageDialog(null, "Erro ao cadastrar a receita: " + e.getMessage());
	    }
	    return idGerado; // Retorna o ID gerado ou -1 em caso de erro
	}
}






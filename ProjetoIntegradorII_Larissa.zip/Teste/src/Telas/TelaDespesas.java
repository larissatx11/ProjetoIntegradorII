package Telas;
import javax.swing.JPanel;
import javax.swing.JLabel;
import java.awt.Color;
import java.awt.Font;

public class TelaDespesas extends JPanel {

	/**
	 * Create the panel.
	 */
	public TelaDespesas() {
		setBounds(0, 0, 691, 498);
		setLayout(null);
		setBackground(Color.WHITE);
		
		JLabel lblNewLabel = new JLabel("Despesas");
		lblNewLabel.setFont(new Font("Century Gothic", Font.BOLD, 30));
		lblNewLabel.setForeground(new Color(40, 66, 159));
		lblNewLabel.setBounds(28, 0, 142, 85);
		add(lblNewLabel);
	}

}
